import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: "NFE Focus Group Portal",
  description: "Upload images, share feedback, and track your progress."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header className="border-b">
          <div className="container-nfe flex items-center justify-between py-4">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-brand-primary" />
              <span className="font-semibold">NFE Focus Group</span>
            </Link>
            <nav className="flex items-center gap-4">
              <Link href="/upload" className="nav-link">Upload</Link>
              <Link href="/feedback" className="nav-link">Feedback</Link>
              <Link href="/profile" className="nav-link">Profile</Link>
              <Link href="/admin" className="nav-link">Admin</Link>
              <Link href="/login" className="nav-link">Login</Link>
            </nav>
          </div>
        </header>
        <main className="container-nfe py-8">{children}</main>
        <footer className="border-t mt-12">
          <div className="container-nfe py-6 text-sm text-gray-500">
            © {new Date().getFullYear()} NFE — Not For Everyone
          </div>
        </footer>
      </body>
    </html>
  );
}
