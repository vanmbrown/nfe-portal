import Link from "next/link";
import { createClient } from "@/lib/supabaseServer";

export default async function Home() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();

  return (
    <div className="grid gap-6">
      <div className="card">
        <h1 className="text-2xl font-semibold mb-2">Welcome to the NFE Focus Group</h1>
        <p className="text-gray-600">
          This portal lets you upload before/after images, share feedback, and track your progress.
        </p>
        <div className="mt-4 flex gap-3">
          <Link href="/upload" className="btn btn-primary">Upload Images</Link>
          <Link href="/feedback" className="btn btn-outline">Give Feedback</Link>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="card">
          <h2 className="font-semibold mb-2">1. Upload</h2>
          <p className="text-gray-600 text-sm">Add your before, during, and after photos with consent options.</p>
        </div>
        <div className="card">
          <h2 className="font-semibold mb-2">2. Feedback</h2>
          <p className="text-gray-600 text-sm">Rate hydration, tone, texture, and share observations.</p>
        </div>
        <div className="card">
          <h2 className="font-semibold mb-2">3. Progress</h2>
          <p className="text-gray-600 text-sm">See your weekly trend and journal entries in one place.</p>
        </div>
      </div>

      {!user && (
        <div className="card">
          <h3 className="font-semibold mb-2">New here?</h3>
          <p className="text-gray-600 text-sm">Create an account or log in to start.</p>
          <div className="mt-2">
            <Link href="/login" className="btn btn-primary">Log in / Register</Link>
          </div>
        </div>
      )}
    </div>
  );
}
