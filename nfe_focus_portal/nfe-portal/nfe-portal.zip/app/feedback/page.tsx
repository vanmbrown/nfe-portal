'use client';

import { useEffect, useState } from 'react';
import { createBrowserClient } from '@/lib/supabaseClient';

type FeedbackRow = {
  id: string;
  user_id: string;
  week_number: number;
  hydration_rating: number;
  tone_evenness_rating: number;
  texture_rating: number;
  scent_rating: number;
  absorption_rating: number;
  overall_satisfaction: number;
  open_feedback: string | null;
  created_at: string;
};

export default function FeedbackPage() {
  const supabase = createBrowserClient();
  const [week, setWeek] = useState(1);
  const [hydration, setHydration] = useState(3);
  const [tone, setTone] = useState(3);
  const [texture, setTexture] = useState(3);
  const [scent, setScent] = useState(3);
  const [absorption, setAbsorption] = useState(3);
  const [overall, setOverall] = useState(3);
  const [open, setOpen] = useState('');
  const [list, setList] = useState<FeedbackRow[]>([]);
  const [msg, setMsg] = useState<string | null>(null);

  const load = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { data, error } = await supabase.from('feedback').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
    if (!error && data) setList(data as FeedbackRow[]);
  };

  useEffect(()=>{ load(); }, []);

  const save = async () => {
    setMsg(null);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const payload = {
      user_id: user.id,
      week_number: week,
      hydration_rating: hydration,
      tone_evenness_rating: tone,
      texture_rating: texture,
      scent_rating: scent,
      absorption_rating: absorption,
      overall_satisfaction: overall,
      open_feedback: open || null
    };
    const { error } = await supabase.from('feedback').insert(payload);
    if (error) setMsg(error.message);
    else { setMsg('Saved.'); setOpen(''); await load(); }
  };

  return (
    <div className="grid gap-6">
      <div className="card max-w-2xl mx-auto">
        <h1 className="text-xl font-semibold mb-3">Weekly Feedback</h1>
        <div className="grid md:grid-cols-3 gap-3">
          <div>
            <label className="label">Week #</label>
            <input className="input" type="number" min={1} max={12} value={week} onChange={e=>setWeek(parseInt(e.target.value||'1'))} />
          </div>
          <div>
            <label className="label">Hydration</label>
            <input className="input" type="number" min={1} max={5} value={hydration} onChange={e=>setHydration(parseInt(e.target.value||'3'))} />
          </div>
          <div>
            <label className="label">Tone Evenness</label>
            <input className="input" type="number" min={1} max={5} value={tone} onChange={e=>setTone(parseInt(e.target.value||'3'))} />
          </div>
          <div>
            <label className="label">Texture</label>
            <input className="input" type="number" min={1} max={5} value={texture} onChange={e=>setTexture(parseInt(e.target.value||'3'))} />
          </div>
          <div>
            <label className="label">Scent</label>
            <input className="input" type="number" min={1} max={5} value={scent} onChange={e=>setScent(parseInt(e.target.value||'3'))} />
          </div>
          <div>
            <label className="label">Absorption</label>
            <input className="input" type="number" min={1} max={5} value={absorption} onChange={e=>setAbsorption(parseInt(e.target.value||'3'))} />
          </div>
          <div>
            <label className="label">Overall</label>
            <input className="input" type="number" min={1} max={5} value={overall} onChange={e=>setOverall(parseInt(e.target.value||'3'))} />
          </div>
        </div>

        <div className="mt-3">
          <label className="label">What’s changed this week?</label>
          <textarea className="textarea" rows={4} value={open} onChange={e=>setOpen(e.target.value)} />
        </div>

        <div className="mt-4">
          <button className="btn btn-primary" onClick={save}>Submit</button>
          {msg && <span className="ml-3 text-sm text-gray-600">{msg}</span>}
        </div>
      </div>

      <div className="card">
        <h2 className="font-semibold mb-2">Your entries</h2>
        <div className="grid gap-3">
          {list.map(item => (
            <div key={item.id} className="border rounded-xl p-3">
              <div className="text-xs text-gray-500">{new Date(item.created_at).toLocaleString()} — Week {item.week_number}</div>
              <div className="text-sm mt-1">Hydration {item.hydration_rating}/5 • Tone {item.tone_evenness_rating}/5 • Texture {item.texture_rating}/5 • Overall {item.overall_satisfaction}/5</div>
              {item.open_feedback && <div className="text-sm mt-1 text-gray-700">{item.open_feedback}</div>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
