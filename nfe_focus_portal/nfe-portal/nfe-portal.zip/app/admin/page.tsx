'use client';

import { useEffect, useMemo, useState } from 'react';
import { createBrowserClient } from '@/lib/supabaseClient';

type FeedbackRow = {
  id: string;
  user_id: string;
  week_number: number;
  hydration_rating: number;
  tone_evenness_rating: number;
  texture_rating: number;
  scent_rating: number;
  absorption_rating: number;
  overall_satisfaction: number;
  open_feedback: string | null;
  created_at: string;
  profiles?: { email?: string | null } | null;
};

export default function AdminPage() {
  const supabase = createBrowserClient();
  const [isAdmin, setIsAdmin] = useState(false);
  const [rows, setRows] = useState<FeedbackRow[]>([]);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(()=>{
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setMsg('Please log in.'); return; }
      const adminEmails = (process.env.NEXT_PUBLIC_ADMIN_EMAILS || '').split(',').map(x=>x.trim().toLowerCase());
      // fallback to server-side env not available on client, so fetch via RPC policy (we'll also show a basic check)
      const email = user.email?.toLowerCase();
      setIsAdmin(email ? adminEmails.includes(email) : false);

      const { data, error } = await supabase
        .from('feedback')
        .select('*, profiles(email)')
        .order('created_at', { ascending: false })
        .limit(500);
      if (!error && data) setRows(data as FeedbackRow[]);
    })();
  }, []);

  const stats = useMemo(() => {
    if (!rows.length) return null;
    const avg = (k: keyof FeedbackRow) => {
      const vals = rows.map(r => Number(r[k]||0));
      return (vals.reduce((a,b)=>a+b,0) / vals.length).toFixed(2);
    };
    return {
      hydration: avg('hydration_rating'),
      tone: avg('tone_evenness_rating'),
      texture: avg('texture_rating'),
      overall: avg('overall_satisfaction'),
      count: rows.length
    };
  }, [rows]);

  if (!isAdmin) {
    return <div className="max-w-lg card mx-auto">Admins only. Add your email to ADMIN_EMAILS env and redeploy.</div>;
  }

  return (
    <div className="grid gap-6">
      <div className="card">
        <h1 className="text-xl font-semibold">Admin Dashboard</h1>
        <p className="text-sm text-gray-600">Aggregated feedback and quick stats.</p>
        {stats && (
          <div className="mt-3 grid grid-cols-2 md:grid-cols-5 gap-3 text-sm">
            <div className="border rounded-xl p-3">Hydration avg<br/><span className="font-semibold">{stats.hydration}</span></div>
            <div className="border rounded-xl p-3">Tone avg<br/><span className="font-semibold">{stats.tone}</span></div>
            <div className="border rounded-xl p-3">Texture avg<br/><span className="font-semibold">{stats.texture}</span></div>
            <div className="border rounded-xl p-3">Overall avg<br/><span className="font-semibold">{stats.overall}</span></div>
            <div className="border rounded-xl p-3">Entries<br/><span className="font-semibold">{stats.count}</span></div>
          </div>
        )}
      </div>

      <div className="card overflow-auto">
        <h2 className="font-semibold mb-2">Recent Feedback</h2>
        <table className="min-w-[800px] w-full text-sm">
          <thead>
            <tr className="text-left border-b">
              <th className="py-2 pr-3">Date</th>
              <th className="py-2 pr-3">User</th>
              <th className="py-2 pr-3">Week</th>
              <th className="py-2 pr-3">Hyd</th>
              <th className="py-2 pr-3">Tone</th>
              <th className="py-2 pr-3">Texture</th>
              <th className="py-2 pr-3">Overall</th>
              <th className="py-2 pr-3">Notes</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.id} className="border-b hover:bg-gray-50">
                <td className="py-2 pr-3">{new Date(r.created_at).toLocaleString()}</td>
                <td className="py-2 pr-3">{r.profiles?.email ?? r.user_id.slice(0,6)}</td>
                <td className="py-2 pr-3">{r.week_number}</td>
                <td className="py-2 pr-3">{r.hydration_rating}</td>
                <td className="py-2 pr-3">{r.tone_evenness_rating}</td>
                <td className="py-2 pr-3">{r.texture_rating}</td>
                <td className="py-2 pr-3">{r.overall_satisfaction}</td>
                <td className="py-2 pr-3 max-w-[400px]">{r.open_feedback}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
