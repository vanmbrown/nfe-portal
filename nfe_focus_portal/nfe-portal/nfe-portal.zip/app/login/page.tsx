'use client';

import { useState } from 'react';
import { createBrowserClient } from '@/lib/supabaseClient';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const supabase = createBrowserClient();

  const handleRegister = async () => {
    setLoading(true); setError(null);
    const { error } = await supabase.auth.signUp({ email, password });
    setLoading(false);
    if (error) setError(error.message);
    else router.push('/profile');
  };

  const handleLogin = async () => {
    setLoading(true); setError(null);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) setError(error.message);
    else router.push('/');
  };

  return (
    <div className="max-w-md mx-auto card">
      <h1 className="text-xl font-semibold mb-4">Log in / Register</h1>
      <label className="label">Email</label>
      <input className="input" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" />
      <label className="label mt-3">Password</label>
      <input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="••••••••" />
      {error && <p className="text-red-600 text-sm mt-2">{error}</p>}
      <div className="mt-4 flex gap-2">
        <button onClick={handleLogin} disabled={loading} className="btn btn-primary">{loading? '...' : 'Log in'}</button>
        <button onClick={handleRegister} disabled={loading} className="btn btn-outline">{loading? '...' : 'Register'}</button>
      </div>
    </div>
  );
}
