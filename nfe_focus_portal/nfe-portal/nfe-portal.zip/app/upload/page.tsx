'use client';

import { useEffect, useState } from 'react';
import { createBrowserClient } from '@/lib/supabaseClient';

type ImageRow = {
  id: string;
  user_id: string;
  image_type: 'before' | 'during' | 'after';
  storage_path: string;
  consent_marketing: boolean;
  created_at: string;
};

export default function UploadPage() {
  const supabase = createBrowserClient();
  const [file, setFile] = useState<File | null>(null);
  const [imageType, setImageType] = useState<'before'|'during'|'after'>('before');
  const [consent, setConsent] = useState(false);
  const [images, setImages] = useState<ImageRow[]>([]);
  const [message, setMessage] = useState<string | null>(null);

  const loadImages = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { data, error } = await supabase.from('images').select('*').eq('user_id', user.id).order('created_at', { ascending: false });
    if (!error && data) setImages(data as ImageRow[]);
  };

  useEffect(()=>{ loadImages(); },[]);

  const handleUpload = async () => {
    setMessage(null);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user || !file) { setMessage("Select a file."); return; }

    // Upload to Supabase storage under user folder
    const ext = file.name.split('.').pop();
    const filePath = `${user.id}/${Date.now()}.${ext}`;
    const { error: uploadErr } = await supabase.storage.from('images').upload(filePath, file, { upsert: false });
    if (uploadErr) { setMessage(uploadErr.message); return; }

    const { error: insertErr } = await supabase.from('images').insert({
      user_id: user.id,
      image_type: imageType,
      storage_path: filePath,
      consent_marketing: consent
    });
    if (insertErr) { setMessage(insertErr.message); return; }

    setFile(null);
    setConsent(false);
    await loadImages();
    setMessage("Uploaded.");
  };

  const publicURL = (path: string) => {
    const { data } = supabase.storage.from('images').getPublicUrl(path);
    return data.publicUrl;
  };

  return (
    <div className="grid gap-6">
      <div className="card max-w-2xl mx-auto">
        <h1 className="text-xl font-semibold mb-2">Upload Images</h1>
        <p className="text-sm text-gray-600 mb-4">Natural lighting, neutral background. Images help track progress.</p>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="label">Image type</label>
            <select className="select" value={imageType} onChange={(e)=>setImageType(e.target.value as any)}>
              <option value="before">Before</option>
              <option value="during">During</option>
              <option value="after">After</option>
            </select>
          </div>
          <div className="flex items-end">
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={consent} onChange={e=>setConsent(e.target.checked)} />
              Consent to use in marketing
            </label>
          </div>
        </div>
        <div className="mt-3">
          <input type="file" onChange={e=>setFile(e.target.files?.[0] ?? null)} />
        </div>
        <div className="mt-4">
          <button className="btn btn-primary" onClick={handleUpload}>Upload</button>
          {message && <span className="ml-3 text-sm text-gray-600">{message}</span>}
        </div>
      </div>

      <div className="card">
        <h2 className="font-semibold mb-3">Your uploaded images</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {images.map(img => (
            <div key={img.id} className="border rounded-xl p-2">
              <div className="text-xs text-gray-500 mb-1">{img.image_type}</div>
              <img src={publicURL(img.storage_path)} alt={img.image_type} className="w-full h-40 object-cover rounded-lg" />
              <div className="text-[11px] mt-1 text-gray-500">{new Date(img.created_at).toLocaleString()}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
