'use client';

import { useEffect, useState } from 'react';
import { createBrowserClient } from '@/lib/supabaseClient';
import { useRouter } from 'next/navigation';

const concernsList = ['Dryness', 'Crepey texture', 'Uneven tone', 'Hyperpigmentation', 'Scarring', 'Sensitivity'];

export default function ProfilePage() {
  const supabase = createBrowserClient();
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [ageRange, setAgeRange] = useState('40–49');
  const [skinTone, setSkinTone] = useState('IV');
  const [concerns, setConcerns] = useState<string[]>([]);
  const [lifestyle, setLifestyle] = useState('');
  const [consentImageUse, setConsentImageUse] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { router.push('/login'); return; }
      const { data, error } = await supabase.from('profiles').select('*').eq('id', user.id).maybeSingle();
      if (data) {
        setAgeRange(data.age_range || '40–49');
        setSkinTone(data.skin_tone || 'IV');
        setConcerns(data.concerns || []);
        setLifestyle(data.lifestyle || '');
        setConsentImageUse(Boolean(data.consent_image_use));
      }
      setLoading(false);
    })();
  }, [supabase, router]);

  const toggleConcern = (c: string) => {
    setConcerns(prev => prev.includes(c) ? prev.filter(x=>x!==c) : [...prev, c]);
  };

  const save = async () => {
    setMessage(null);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const payload = {
      id: user.id,
      age_range: ageRange,
      skin_tone: skinTone,
      concerns,
      lifestyle,
      consent_image_use: consentImageUse
    };
    const { error } = await supabase.from('profiles').upsert(payload).eq('id', user.id);
    if (error) setMessage(error.message);
    else setMessage('Saved.');
  };

  if (loading) return <div>Loading…</div>;

  return (
    <div className="max-w-2xl mx-auto card">
      <h1 className="text-xl font-semibold mb-4">Your Profile</h1>
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <label className="label">Age range</label>
          <select className="select" value={ageRange} onChange={e=>setAgeRange(e.target.value)}>
            <option>40–49</option><option>50–59</option><option>60+</option>
          </select>
        </div>
        <div>
          <label className="label">Fitzpatrick Skin Tone</label>
          <select className="select" value={skinTone} onChange={e=>setSkinTone(e.target.value)}>
            <option>I</option><option>II</option><option>III</option><option>IV</option><option>V</option><option>VI</option>
          </select>
        </div>
      </div>

      <div className="mt-4">
        <label className="label">Top concerns</label>
        <div className="grid grid-cols-2 gap-2">
          {concernsList.map(c => (
            <label key={c} className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={concerns.includes(c)} onChange={()=>toggleConcern(c)} />
              {c}
            </label>
          ))}
        </div>
      </div>

      <div className="mt-4">
        <label className="label">Lifestyle (optional)</label>
        <input className="input" value={lifestyle} onChange={e=>setLifestyle(e.target.value)} placeholder="Wellness-focused, minimalist, etc." />
      </div>

      <div className="mt-4">
        <label className="flex items-center gap-2">
          <input type="checkbox" checked={consentImageUse} onChange={e=>setConsentImageUse(e.target.checked)} />
          I consent to the use of my images for testimonials/marketing.
        </label>
      </div>

      <div className="mt-4">
        <button className="btn btn-primary" onClick={save}>Save</button>
        {message && <span className="ml-3 text-sm text-gray-600">{message}</span>}
      </div>
    </div>
  );
}
