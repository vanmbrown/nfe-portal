# NFE Focus Group Portal (Free-Tier MVP)

A full-stack Next.js + Supabase implementation so NFE focus group participants can **register**, **upload images**, and **submit feedback**, while the **admin** sees aggregated insights.

## Tech Stack (All Free Tiers)
- **Next.js 14 (App Router)** — UI + server components
- **Tailwind CSS** — styling
- **Supabase** — Auth, Postgres DB, and Storage (images)
- **Vercel** — zero-cost hosting (Frontend & Next serverless)

---

## 1) One-Time Setup

### A) Create a Supabase project
1. Go to https://supabase.com/ and create a free project.
2. In **Project Settings → API**, copy the **Project URL** and **anon public key**.
3. In **Project Settings → API**, also copy the **service role key** (server-only, do **not** expose to client).

### B) Database schema & policies
1. Open **SQL Editor** and run the contents of:  
   `supabase/schema.sql`
2. Open **SQL Editor** again and run:  
   `supabase/storage_policies.sql`
3. In **Storage → Buckets**, you should now see a bucket called `images`.

> Optional: if you want to keep the images *private*, set the bucket to `public=false` and use Supabase **signed URLs** in the app (already supported via the Storage API).

### C) Configure admin emails
Set a Postgres parameter `app.admin_emails` with comma-separated admin emails:

```sql
-- Replace with your real email(s)
alter system set app.admin_emails = 'vanessa@example.com';
select pg_reload_conf();
```

On Supabase, you can store this via **Database → Config** or run the SQL above.

### D) Local environment
Copy `.env.example` → `.env.local` and fill in:

```
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key

# (Optional in this implementation; kept for future server routes)
SUPABASE_SERVICE_ROLE=your_service_role_key

# Used only on client as a hint; true auth is enforced by DB policies
ADMIN_EMAILS=vanessa@example.com
```

---

## 2) Run Locally

```bash
pnpm install   # or npm install / yarn
pnpm dev       # http://localhost:3000
```

Create a user at **/login**, complete your **/profile**, then:
- Upload images at **/upload**
- Submit feedback at **/feedback**
- View admin dashboard at **/admin** (must be in ADMIN_EMAILS + DB param)

---

## 3) Deploy to Vercel (Free)

1. Push this repo to GitHub.
2. Import project into **Vercel**.
3. Add the following **Environment Variables** in Vercel → Settings → Environment Variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `ADMIN_EMAILS` (same as DB parameter list)
4. Deploy. That’s it.

---

## 4) Notes on Security & Privacy

- **RLS (Row Level Security)** is enforced on all tables so users can only access their own rows.
- Storage bucket policies restrict users to their own `user_id/*` folder for uploads.
- For **truly private images**, set the bucket to not public and switch to **signed URLs** when rendering. The current setup uses public URLs for simplicity.
- Collect explicit **image consent** (stored in `profiles.consent_image_use` and per-image `consent_marketing` flag).

---

## 5) Folder Overview

```
app/
  ├─ page.tsx           # Landing
  ├─ login/             # Auth (email/password)
  ├─ profile/           # Participant profile + consent
  ├─ upload/            # Image upload (before/during/after)
  ├─ feedback/          # Weekly feedback form + history
  └─ admin/             # Admin dashboard & aggregates
lib/
  ├─ supabaseClient.ts  # Client-side Supabase
  └─ supabaseServer.ts  # Server-side Supabase
supabase/
  ├─ schema.sql         # Tables and RLS
  └─ storage_policies.sql
```

---

## 6) Extending the MVP

- **Progress charts**: add a simple charting lib (e.g., chart.js) to graph hydration/overall over time.
- **Keyword analysis**: run periodic scripts to summarize open text into themes.
- **Invites / join codes**: add a `join_codes` table and gate registration on valid tokens.
- **Private image rendering**: turn off public bucket and use URL signing.

---

## 7) Troubleshooting

- **Admin page says “Admins only”**: ensure both Vercel `ADMIN_EMAILS` and DB `app.admin_emails` include your email; re-login.
- **Uploads failing**: confirm your `images` bucket exists and policies were executed.
- **RLS errors**: re-run `schema.sql` to ensure policies are present and RLS is enabled.
- **CORS / keys**: your `NEXT_PUBLIC_*` keys must match your Supabase project.

---

Built for the NFE Focus Group: a privacy-conscious, customer-centric insights hub.
