-- Create Storage bucket and policies (run in Supabase SQL editor)

-- 1) Bucket
insert into storage.buckets (id, name, public) values ('images', 'images', true)
on conflict (id) do nothing;

-- 2) RLS policies for storage.objects
--   Folder structure: images/{user_id}/{filename}
--   Users can manage files in their own folder; admins can read all.

-- READ: allow public read of files (for simplicity) OR restrict to signed URLs only.
-- If you prefer private files, set bucket public=false above and rely on signed URLs.
create policy "Public read access" on storage.objects
for select using (bucket_id = 'images');

-- INSERT: only owner path
create policy "Users can upload to their folder" on storage.objects
for insert to authenticated
with check (
  bucket_id = 'images' and
  (storage.foldername(name))[1] = auth.uid()::text
);

-- UPDATE/DELETE: only owner
create policy "Users can update their files" on storage.objects
for update to authenticated using (
  bucket_id = 'images' and (storage.foldername(name))[1] = auth.uid()::text
);
create policy "Users can delete their files" on storage.objects
for delete to authenticated using (
  bucket_id = 'images' and (storage.foldername(name))[1] = auth.uid()::text
);
