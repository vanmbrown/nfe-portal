-- NFE Focus Group — Supabase schema & RLS policies

-- 1) Profiles (extends auth.users)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text generated always as (lower((auth.jwt() ->> 'email')::text)) stored,
  age_range text,
  skin_tone text,
  concerns text[],
  lifestyle text,
  consent_image_use boolean default false,
  created_at timestamptz default now()
);

-- 2) Feedback
create table if not exists public.feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  week_number int check (week_number >= 1 and week_number <= 52),
  hydration_rating int check (hydration_rating between 1 and 5),
  tone_evenness_rating int check (tone_evenness_rating between 1 and 5),
  texture_rating int check (texture_rating between 1 and 5),
  scent_rating int check (scent_rating between 1 and 5),
  absorption_rating int check (absorption_rating between 1 and 5),
  overall_satisfaction int check (overall_satisfaction between 1 and 5),
  open_feedback text,
  created_at timestamptz default now()
);

-- 3) Images (metadata – actual files in Storage bucket `images`)
create table if not exists public.images (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  image_type text check (image_type in ('before', 'during', 'after')) not null,
  storage_path text not null,
  consent_marketing boolean default false,
  created_at timestamptz default now()
);

-- Enable Row Level Security
alter table public.profiles enable row level security;
alter table public.feedback enable row level security;
alter table public.images enable row level security;

-- Policies: Users can CRUD their own data; admins can read all
-- Define admin email list as a simple helper function
create or replace function public.is_admin()
returns boolean language sql stable as $$
  select coalesce(lower(auth.jwt() ->> 'email') in (select unnest(string_to_array(current_setting('app.admin_emails', true), ','))), false);
$$;

-- Set the admin emails at runtime: 
--   call: alter system set app.admin_emails = 'vanessa@example.com,other@example.com';
-- (On Supabase, use 'Config Variables' to set a DB parameter app.admin_emails)

-- PROFILES policies
create policy if not exists "Profiles: users can view their own"
  on public.profiles for select using (auth.uid() = id or public.is_admin());

create policy if not exists "Profiles: users can upsert their own"
  on public.profiles for insert with check (auth.uid() = id);
create policy if not exists "Profiles: users can update their own"
  on public.profiles for update using (auth.uid() = id);

-- FEEDBACK policies
create policy if not exists "Feedback: read own or admin"
  on public.feedback for select using (auth.uid() = user_id or public.is_admin());
create policy if not exists "Feedback: insert own"
  on public.feedback for insert with check (auth.uid() = user_id);
create policy if not exists "Feedback: update own"
  on public.feedback for update using (auth.uid() = user_id);
create policy if not exists "Feedback: delete own"
  on public.feedback for delete using (auth.uid() = user_id or public.is_admin());

-- IMAGES policies
create policy if not exists "Images: read own or admin"
  on public.images for select using (auth.uid() = user_id or public.is_admin());
create policy if not exists "Images: insert own"
  on public.images for insert with check (auth.uid() = user_id);
create policy if not exists "Images: update own"
  on public.images for update using (auth.uid() = user_id);
create policy if not exists "Images: delete own"
  on public.images for delete using (auth.uid() = user_id or public.is_admin());
